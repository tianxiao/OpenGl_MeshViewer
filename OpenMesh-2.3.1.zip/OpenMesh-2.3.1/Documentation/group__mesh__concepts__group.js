var group__mesh__concepts__group =
[
    [ "MeshItems", "structOpenMesh_1_1Concepts_1_1MeshItems.html", null ],
    [ "KernelT", "classOpenMesh_1_1Concepts_1_1KernelT.html", null ]
];