var classOpenMeshDecimater =
[
    [ "SetUp", "classOpenMeshDecimater.html#abebdbb482c5cd43e0d4ba93e5f0ab09e", null ],
    [ "TearDown", "classOpenMeshDecimater.html#acd34ce28e739815bb089e373de17528d", null ]
];