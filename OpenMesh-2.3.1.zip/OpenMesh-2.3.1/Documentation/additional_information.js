var additional_information =
[
    [ "Notes on template programming", "mesh_first_to_read.html", null ],
    [ "Some words on the C++ implementation", "mesh_cpp.html", null ],
    [ "Where do I find a list of all member functions ?", "mesh_members.html", null ],
    [ "Naming Conventions", "naming_conventions.html", null ],
    [ "Changelog", "om_changelog.html", null ]
];