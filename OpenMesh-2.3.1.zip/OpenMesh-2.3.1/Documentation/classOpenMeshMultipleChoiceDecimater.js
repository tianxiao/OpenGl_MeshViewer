var classOpenMeshMultipleChoiceDecimater =
[
    [ "SetUp", "classOpenMeshMultipleChoiceDecimater.html#a0a4e3b58814b3762a6189fdda518d55e", null ],
    [ "TearDown", "classOpenMeshMultipleChoiceDecimater.html#af161544bedb2894e3bcea01013ecd1eb", null ]
];