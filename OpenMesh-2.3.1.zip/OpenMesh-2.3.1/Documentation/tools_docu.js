var tools_docu =
[
    [ "Mesh Decimation Framework", "decimater_docu.html", [
      [ "The decimation algorithm", "decimater_docu.html#DecimaterAlg", null ],
      [ "Decimating Modules", "decimater_docu.html#DecimaterMod", null ],
      [ "Module Handles", "decimater_docu.html#DecimaterHnd", null ],
      [ "Basic Setup", "decimater_docu.html#DecimaterExa", null ]
    ] ],
    [ "Sudivision Tools", "subdivider_docu.html", [
      [ "Overview", "subdivider_docu.html#Overview", null ],
      [ "Usage", "subdivider_docu.html#Usage", null ]
    ] ],
    [ "View Dependent Progressive Meshes", "vdpm_docu.html", null ]
];