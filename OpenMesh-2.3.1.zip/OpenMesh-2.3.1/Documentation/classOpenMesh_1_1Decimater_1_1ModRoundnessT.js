var classOpenMesh_1_1Decimater_1_1ModRoundnessT =
[
    [ "Base", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#af8546d52b77726437395750b2eaa0cdb", null ],
    [ "CollapseInfo", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a67e401883de3a0ec5ecdc1bb7e7e8937", null ],
    [ "Handle", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a29ea31458ca5f541fc4d4c342ba9cd5a", null ],
    [ "Mesh", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a3864b942ad7a74c389fb283bd55d1d73", null ],
    [ "Point", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a2adc39c5cf710c882f976614ea36eee2", null ],
    [ "Self", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#ab05734e6a95d6e330c6d115a2af8dc19", null ],
    [ "value_type", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#ae55ef761370282e939141ad9eaccd6ba", null ],
    [ "ModRoundnessT", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a6e56da8acf8ce9a37577c07764e5c98b", null ],
    [ "~ModRoundnessT", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a7b6ea799f3e162748ea4612654c56eb5", null ],
    [ "collapse_priority", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#ade6fe704e576b3e0f73453ffd8cad0fd", null ],
    [ "name", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#adbb0d330e11876fccd5a98dc50ea6f7f", null ],
    [ "roundness", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a589e3679e530a184543609d23c585bf6", null ],
    [ "set_error_tolerance_factor", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a14fa6c8dc43d6621a3c0cb5404e1a5de", null ],
    [ "set_min_angle", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#ab33b28845de4cbd93fa21012522e9275", null ],
    [ "set_min_roundness", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a825e256b8e67059958ad809e9ace85c3", null ],
    [ "unset_min_roundness", "classOpenMesh_1_1Decimater_1_1ModRoundnessT.html#a1269b89dd5b20adbf0d81a7a86cc549b", null ]
];