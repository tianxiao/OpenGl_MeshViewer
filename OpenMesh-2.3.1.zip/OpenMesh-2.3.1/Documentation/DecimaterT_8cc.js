var DecimaterT_8cc =
[
    [ "OPENMESH_DECIMATER_DECIMATERT_CC", "DecimaterT_8cc.html#ab8077407ec24725ad2a2557a65df9a3b", null ]
];